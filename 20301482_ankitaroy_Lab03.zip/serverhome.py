# -*- coding: utf-8 -*-
"""
Created on Tue Mar 15 10:19:32 2022

@author: hp
"""
HEADER=64
FORMAT="utf-8"
DISCONNECT_MSG="end"
import socket
SERVER= socket.gethostbyname(socket.gethostname())
PORT= 5050
ADDR= (SERVER,PORT)
server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(ADDR)
print("Server is starting.......")
server.listen()
print("Server is listening on ",SERVER)
while True:
    conn,addr=server.accept()
    print("connected to",addr)
    connected=True
    while connected:
        msg_length=conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length=int(msg_length)
            msg=conn.recv(msg_length).decode(FORMAT)
            if msg==DISCONNECT_MSG:
                connected=False
                conn.send(f'terminating connection with {addr}'.encode(FORMAT))
            else:
                try:
                    hours=int(msg)
                    salary=0
                    if hours<=40:
                        salary=200*hours
                    else:
                        salary=8000+ (hours-40)*300
                    conn.send(f" salary = {salary}".encode(FORMAT))
                except ValueError:
                    conn.send("Error....".encode(FORMAT))
                    
    conn.close()

