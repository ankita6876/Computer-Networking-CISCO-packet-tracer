# -*- coding: utf-8 -*-
"""
Created on Mon Mar 14 10:44:16 2022

@author: hp
"""
HEADER=64
FORMAT="utf-8"
DISCONNECT_MSG="end"
import socket
SERVER= socket.gethostbyname(socket.gethostname())
PORT= 5050
ADDR= (SERVER,PORT)
server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(ADDR)
print("Server is starting.......")
server.listen()
print("Server is listening on ",SERVER)
conn,addr=server.accept()
print("connected to",addr)
connected=True
while connected:
    msg_length=conn.recv(HEADER).decode(FORMAT)
    if msg_length:
        msg_length=int(msg_length)
        msg=conn.recv(msg_length).decode(FORMAT)
        if msg==DISCONNECT_MSG:
            connected=False
            conn.send(f'terminating connection with {addr}'.encode(FORMAT))
        else:
            print(msg)
            conn.send('Message Received'.encode(FORMAT))
conn.close()