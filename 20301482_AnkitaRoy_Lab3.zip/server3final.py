import threading
HEADER = 64
FORMAT = "utf-8"
DISCONNECT_MSG = "end"
import socket

SERVER = socket.gethostbyname(socket.gethostname())
PORT = 5050
ADDR = (SERVER, PORT)
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)
def handle_client(conn,addr):
    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(FORMAT)
            if msg == DISCONNECT_MSG:
                connected = False
                conn.send(f'terminating connection with {addr}'.encode(FORMAT))
            else:
                try:
                    string = msg
                    num_vowels = 0
                    for char in string:
                        if char in "aeiouAEIOU":
                            num_vowels = num_vowels + 1
                    if num_vowels == 0:
                        conn.send("Not enough vowels".encode(FORMAT))
                    if num_vowels <= 2:
                        conn.send("Enough vowels i guess".encode(FORMAT))
                    if num_vowels > 2:
                        conn.send("Too many vowels".encode(FORMAT))
                except ValueError:
                    conn.send("Error....".encode(FORMAT))

    conn.close()
def start():
    print("Server is starting.......")
    server.listen()
    print("Server is listening on ", SERVER)
    while True:
        conn, addr = server.accept()
        print("connected to", addr)
        thread=threading.Thread(target=handle_client,args=(conn,addr))
        thread.start()
start()

